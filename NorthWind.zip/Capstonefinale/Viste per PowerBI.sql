/* creo una tabella con le aree di vendita assegno ad ogni paese la sua area di vendita
per poi ccreare una vista per mezzo di una self Join*/

CREATE TABLE SalesArea
(	PK_RegID INT PRIMARY KEY,
	FK_RegParentID INT FOREIGN KEY REFERENCES SalesArea(PK_RegID),
	RegName NVARCHAR(50));

	INSERT INTO SalesArea
	(	PK_RegID,
		FK_RegParentID,
		RegName)

			VALUES	(3, NULL, 'North America'),
				(5,NULL,'Central/South America'),
				(7,NULL,'Europe'),
				(9,NULL,'Scandinavian Europe'),
					
					(10,7,'Austria'),
					(11,5,'Brazil'),
					(12,9,'Denmark'), 	
					(13,9 ,'Finland'),		
					(14,7,'France'),		
					(15,7,'Germany'),		
					(16,7,'Ireland'),		
					(17,7,'Italy'),				
					(18,5,'Mexico'),	
					(19,5,'Argentina'),		
					(20,7,'Poland'),
					(21,7,'Portugal'),
					(22,9,'Norway'),
					(23,7,'Spain'),
					(24,9,'Sweden'),
					(25,7,'Switzerland'),			
					(26,7,'UK'),	
					(27,5,'Venezuela'),
					(28,3,'USA'),	
					(29,3,'Canada'),					
					(30,7,'Belgium');



CREATE VIEW NVM_VW_SALESAREA AS(
SELECT	Sa1.RegName AS StateName,
Sa2.RegName AS SalesArea,
Sa1.PK_RegID
FROM SalesArea AS Sa1
JOIN SalesArea as Sa2
ON Sa1.FK_RegParentID = Sa2.PK_RegID);


/* Implemento una vista per poi creare in Power BI una tabella con i soli dati dei costi 
di spedizione e dell'identificativo dell'ordine, per poter analizzare le spedizioni*/


CREATE VIEW NVM_SHIPDATA AS(
SELECT OrderID,ShipVia,Freight
FROM Orders)
